"""
Tamper-evident audit logging. Each entry hashes its own content together with
the previous entry's hash, forming a chain. Walking the chain and recomputing
hashes reveals any retroactive edit or deletion.
"""
import hashlib
import json
from datetime import datetime

from sqlalchemy.orm import Session

import models


def _compute_hash(prev_hash: str, entity_type: str, entity_id: int, action: str,
                   actor_id, details: str, timestamp: datetime) -> str:
    payload = json.dumps({
        "prev_hash": prev_hash,
        "entity_type": entity_type,
        "entity_id": entity_id,
        "action": action,
        "actor_id": actor_id,
        "details": details,
        "timestamp": timestamp.isoformat(),
    }, sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def log_action(db: Session, entity_type: str, entity_id: int, action: str,
                actor_id=None, details: dict | None = None) -> models.AuditLog:
    last = db.query(models.AuditLog).order_by(models.AuditLog.id.desc()).first()
    prev_hash = last.entry_hash if last else None
    timestamp = datetime.utcnow()
    details_json = json.dumps(details) if details is not None else None

    entry_hash = _compute_hash(prev_hash, entity_type, entity_id, action, actor_id, details_json, timestamp)

    entry = models.AuditLog(
        entity_type=entity_type,
        entity_id=entity_id,
        action=action,
        actor_id=actor_id,
        details=details_json,
        timestamp=timestamp,
        prev_hash=prev_hash,
        entry_hash=entry_hash,
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


def verify_chain(db: Session) -> tuple[bool, int | None]:
    """Re-walks the entire audit log and recomputes hashes. Returns (is_valid, first_broken_id)."""
    entries = db.query(models.AuditLog).order_by(models.AuditLog.id.asc()).all()
    prev_hash = None
    for entry in entries:
        expected = _compute_hash(
            prev_hash, entry.entity_type, entry.entity_id, entry.action,
            entry.actor_id, entry.details, entry.timestamp
        )
        if expected != entry.entry_hash or entry.prev_hash != prev_hash:
            return False, entry.id
        prev_hash = entry.entry_hash
    return True, None
