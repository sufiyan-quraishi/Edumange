from datetime import datetime
from typing import Optional, List

from pydantic import BaseModel, Field

from models import Role, ResultStatus, ReviewStatus, ReferralStatus


# ---------- Auth ----------

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: Role
    full_name: str


class UserCreate(BaseModel):
    username: str
    full_name: str
    password: str
    role: Role = Role.officer
    badge_id: Optional[str] = None


class UserOut(BaseModel):
    id: int
    username: str
    full_name: str
    role: Role
    badge_id: Optional[str] = None

    class Config:
        from_attributes = True


# ---------- Case ----------

class CaseCreate(BaseModel):
    case_number: str
    title: str
    description: Optional[str] = None


class CaseOut(BaseModel):
    id: int
    case_number: str
    title: str
    description: Optional[str]
    status: str
    created_at: datetime

    class Config:
        from_attributes = True


# ---------- Evidence ----------

class EvidenceCreate(BaseModel):
    case_id: int
    description: str
    seized_location: Optional[str] = None


class EvidenceOut(BaseModel):
    id: int
    evidence_code: str
    case_id: int
    description: str
    seized_location: Optional[str]
    seized_at: datetime

    class Config:
        from_attributes = True


# ---------- Field Test Event ----------

class FieldTestEventCreate(BaseModel):
    """
    Shape used both for direct online creation and for offline-queued sync.
    client_uid lets the frontend generate an ID offline; the backend treats
    event_uid as authoritative and idempotency key on sync.
    """
    event_uid: Optional[str] = None   # if omitted, server generates one
    evidence_id: int
    test_kit_type: Optional[str] = None
    observation: str
    preliminary_result: str
    result_status: ResultStatus = ResultStatus.preliminary
    location_lat: Optional[float] = None
    location_lng: Optional[float] = None
    media_refs: Optional[List[str]] = None
    client_created_at: Optional[datetime] = None


class FieldTestEventOut(BaseModel):
    id: int
    event_uid: str
    evidence_id: int
    officer_id: int
    test_kit_type: Optional[str]
    observation: str
    preliminary_result: str
    result_status: ResultStatus
    review_status: ReviewStatus
    reviewed_by: Optional[int]
    reviewed_at: Optional[datetime]
    supervisor_notes: Optional[str]
    location_lat: Optional[float]
    location_lng: Optional[float]
    client_created_at: Optional[datetime]
    synced_at: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True


class ReviewUpdate(BaseModel):
    review_status: ReviewStatus
    supervisor_notes: Optional[str] = None


class SyncBatch(BaseModel):
    """A batch of field-test events queued on-device while offline."""
    events: List[FieldTestEventCreate]


class SyncResult(BaseModel):
    accepted: List[str]   # event_uids accepted
    duplicates: List[str]  # event_uids already present (idempotent no-op)


# ---------- Lab Referral ----------

class ReferralUpdate(BaseModel):
    status: ReferralStatus
    lab_name: Optional[str] = None
    notes: Optional[str] = None


class ReferralOut(BaseModel):
    id: int
    field_test_event_id: int
    status: ReferralStatus
    lab_name: Optional[str]
    notes: Optional[str]
    updated_at: datetime

    class Config:
        from_attributes = True


# ---------- Timeline / Audit ----------

class AuditLogOut(BaseModel):
    id: int
    entity_type: str
    entity_id: int
    action: str
    actor_id: Optional[int]
    details: Optional[str]
    timestamp: datetime
    prev_hash: Optional[str]
    entry_hash: str

    class Config:
        from_attributes = True


class TimelineEntry(BaseModel):
    timestamp: datetime
    label: str
    actor: Optional[str] = None
    detail: Optional[str] = None
