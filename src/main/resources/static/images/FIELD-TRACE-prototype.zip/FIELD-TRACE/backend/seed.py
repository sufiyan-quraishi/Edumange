"""
Creates demo accounts and a starter case/evidence record so the app can be
demoed immediately after install. Safe to re-run (skips existing rows).

    python seed.py
"""
from database import Base, engine, SessionLocal
import models
from auth import hash_password

Base.metadata.create_all(bind=engine)
db = SessionLocal()

DEMO_USERS = [
    dict(username="officer1", full_name="Const. R. Sharma", password="officer123",
         role=models.Role.officer, badge_id="MH-0451"),
    dict(username="supervisor1", full_name="Insp. A. Verma", password="super123",
         role=models.Role.supervisor, badge_id="MH-0110"),
    dict(username="lab1", full_name="Dr. S. Iyer, FSL", password="lab123",
         role=models.Role.forensic, badge_id="FSL-2203"),
    dict(username="admin", full_name="System Administrator", password="admin123",
         role=models.Role.admin, badge_id=None),
]

for u in DEMO_USERS:
    if not db.query(models.User).filter(models.User.username == u["username"]).first():
        user = models.User(
            username=u["username"],
            full_name=u["full_name"],
            hashed_password=hash_password(u["password"]),
            role=u["role"],
            badge_id=u["badge_id"],
        )
        db.add(user)
        print(f"created user: {u['username']} / {u['password']} ({u['role'].value})")

db.commit()

officer = db.query(models.User).filter(models.User.username == "officer1").first()

if not db.query(models.Case).filter(models.Case.case_number == "MH-CR-2026-0142").first():
    case = models.Case(
        case_number="MH-CR-2026-0142",
        title="NDPS Act — Roadside Interception, Pune Bypass",
        description="Demo case for prototype walkthrough. Not a real record.",
        created_by=officer.id,
    )
    db.add(case)
    db.commit()
    db.refresh(case)

    evidence = models.Evidence(
        case_id=case.id,
        description="Sealed polythene packet, off-white crystalline substance, approx. 12g",
        seized_location="Pune Bypass, KM marker 14",
        created_by=officer.id,
    )
    db.add(evidence)
    db.commit()
    print(f"created demo case {case.case_number} with evidence {evidence.evidence_code}")

db.close()
print("\nSeed complete. Demo logins:")
for u in DEMO_USERS:
    print(f"  {u['role'].value:<11} username={u['username']:<12} password={u['password']}")
