"""
Core data model: Case -> Evidence -> FieldTestEvent, plus AuditLog (hash-chained,
tamper-evident) and LabReferral for the field-to-forensic handoff.
"""
import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    Column, String, Integer, Float, DateTime, ForeignKey, Enum, Text, Boolean
)
from sqlalchemy.orm import relationship

from database import Base


def gen_uuid():
    return str(uuid.uuid4())


class Role(str, enum.Enum):
    officer = "officer"
    supervisor = "supervisor"
    forensic = "forensic"
    admin = "admin"


class ResultStatus(str, enum.Enum):
    preliminary = "preliminary"        # field observation only
    confirmed = "confirmed"            # laboratory-confirmed
    inconclusive = "inconclusive"


class ReviewStatus(str, enum.Enum):
    pending = "pending"
    reviewed = "reviewed"
    flagged = "flagged"


class ReferralStatus(str, enum.Enum):
    not_referred = "not_referred"
    referred = "referred"
    in_analysis = "in_analysis"
    completed = "completed"


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    full_name = Column(String, nullable=False)
    hashed_password = Column(String, nullable=False)
    role = Column(Enum(Role), nullable=False, default=Role.officer)
    badge_id = Column(String, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Case(Base):
    __tablename__ = "cases"

    id = Column(Integer, primary_key=True, index=True)
    case_number = Column(String, unique=True, index=True, nullable=False)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    status = Column(String, default="open")
    created_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)

    evidence_items = relationship("Evidence", back_populates="case", cascade="all, delete-orphan")


class Evidence(Base):
    __tablename__ = "evidence"

    id = Column(Integer, primary_key=True, index=True)
    evidence_code = Column(String, unique=True, index=True, default=gen_uuid)  # unique evidence ID
    case_id = Column(Integer, ForeignKey("cases.id"), nullable=False)
    description = Column(Text, nullable=False)
    seized_location = Column(String, nullable=True)
    seized_at = Column(DateTime, default=datetime.utcnow)
    created_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)

    case = relationship("Case", back_populates="evidence_items")
    field_tests = relationship("FieldTestEvent", back_populates="evidence", cascade="all, delete-orphan")


class FieldTestEvent(Base):
    __tablename__ = "field_test_events"

    id = Column(Integer, primary_key=True, index=True)
    event_uid = Column(String, unique=True, index=True, default=gen_uuid)  # unique evidence-event ID
    evidence_id = Column(Integer, ForeignKey("evidence.id"), nullable=False)
    officer_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    test_kit_type = Column(String, nullable=True)          # e.g. "NCB presumptive kit - opiates"
    observation = Column(Text, nullable=False)               # raw field observation
    preliminary_result = Column(String, nullable=False)      # e.g. "presumptive positive - opiates"
    result_status = Column(Enum(ResultStatus), default=ResultStatus.preliminary, nullable=False)

    location_lat = Column(Float, nullable=True)
    location_lng = Column(Float, nullable=True)

    review_status = Column(Enum(ReviewStatus), default=ReviewStatus.pending)
    reviewed_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    reviewed_at = Column(DateTime, nullable=True)
    supervisor_notes = Column(Text, nullable=True)

    media_refs = Column(Text, nullable=True)  # JSON-encoded list of filenames/refs

    # Offline-first bookkeeping
    client_created_at = Column(DateTime, nullable=True)  # timestamp set on device, possibly offline
    synced_at = Column(DateTime, nullable=True)           # server time when the record was received
    created_at = Column(DateTime, default=datetime.utcnow)

    evidence = relationship("Evidence", back_populates="field_tests")
    referral = relationship("LabReferral", back_populates="field_test", uselist=False, cascade="all, delete-orphan")


class LabReferral(Base):
    __tablename__ = "lab_referrals"

    id = Column(Integer, primary_key=True, index=True)
    field_test_event_id = Column(Integer, ForeignKey("field_test_events.id"), unique=True, nullable=False)
    status = Column(Enum(ReferralStatus), default=ReferralStatus.not_referred)
    lab_name = Column(String, nullable=True)
    notes = Column(Text, nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    field_test = relationship("FieldTestEvent", back_populates="referral")


class AuditLog(Base):
    """
    Tamper-evident audit trail: each row stores a SHA-256 hash of its own content
    chained to the previous row's hash (prev_hash). Any retroactive edit breaks
    the chain and can be detected by re-walking and recomputing hashes.
    """
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    entity_type = Column(String, nullable=False)   # "case" | "evidence" | "field_test_event" | "referral"
    entity_id = Column(Integer, nullable=False)
    action = Column(String, nullable=False)         # "create" | "update" | "review" | "sync" | "login"
    actor_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    details = Column(Text, nullable=True)            # JSON-encoded diff/context
    timestamp = Column(DateTime, default=datetime.utcnow)

    prev_hash = Column(String, nullable=True)
    entry_hash = Column(String, nullable=False)
