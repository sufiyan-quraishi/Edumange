"""
FIELD-TRACE backend — FastAPI prototype.

Implements the flow from the prototype plan:
officer login -> case -> evidence -> field-test event -> offline sync ->
report -> supervisor review -> timeline/audit trail -> simulated lab status.

Run:
    pip install -r requirements.txt
    python seed.py        # creates demo users/case/evidence
    uvicorn main:app --reload
"""
import json
from datetime import datetime
from typing import List, Optional

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

import models
import schemas
from database import Base, engine, get_db
from auth import (
    verify_password, hash_password, create_access_token, get_current_user, require_roles
)
from audit import log_action, verify_chain

Base.metadata.create_all(bind=engine)

app = FastAPI(title="FIELD-TRACE API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # prototype only — restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

@app.post("/auth/login", response_model=schemas.Token)
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == form_data.username).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Incorrect username or password")
    token = create_access_token({"sub": user.username, "role": user.role.value})
    log_action(db, "user", user.id, "login", actor_id=user.id)
    return schemas.Token(access_token=token, role=user.role, full_name=user.full_name)


@app.post("/auth/register", response_model=schemas.UserOut)
def register(payload: schemas.UserCreate, db: Session = Depends(get_db),
             _: models.User = Depends(require_roles(models.Role.admin))):
    if db.query(models.User).filter(models.User.username == payload.username).first():
        raise HTTPException(status_code=400, detail="Username already exists")
    user = models.User(
        username=payload.username,
        full_name=payload.full_name,
        hashed_password=hash_password(payload.password),
        role=payload.role,
        badge_id=payload.badge_id,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    log_action(db, "user", user.id, "create", actor_id=user.id, details={"role": user.role.value})
    return user


@app.get("/auth/me", response_model=schemas.UserOut)
def me(current_user: models.User = Depends(get_current_user)):
    return current_user


# ---------------------------------------------------------------------------
# Cases
# ---------------------------------------------------------------------------

@app.post("/cases", response_model=schemas.CaseOut)
def create_case(payload: schemas.CaseCreate, db: Session = Depends(get_db),
                 current_user: models.User = Depends(get_current_user)):
    if db.query(models.Case).filter(models.Case.case_number == payload.case_number).first():
        raise HTTPException(status_code=400, detail="Case number already exists")
    case = models.Case(**payload.model_dump(), created_by=current_user.id)
    db.add(case)
    db.commit()
    db.refresh(case)
    log_action(db, "case", case.id, "create", actor_id=current_user.id,
               details={"case_number": case.case_number, "title": case.title})
    return case


@app.get("/cases", response_model=List[schemas.CaseOut])
def list_cases(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    return db.query(models.Case).order_by(models.Case.created_at.desc()).all()


@app.get("/cases/{case_id}", response_model=schemas.CaseOut)
def get_case(case_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    case = db.query(models.Case).get(case_id)
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    return case


# ---------------------------------------------------------------------------
# Evidence
# ---------------------------------------------------------------------------

@app.post("/evidence", response_model=schemas.EvidenceOut)
def create_evidence(payload: schemas.EvidenceCreate, db: Session = Depends(get_db),
                     current_user: models.User = Depends(get_current_user)):
    case = db.query(models.Case).get(payload.case_id)
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    evidence = models.Evidence(**payload.model_dump(), created_by=current_user.id)
    db.add(evidence)
    db.commit()
    db.refresh(evidence)
    log_action(db, "evidence", evidence.id, "create", actor_id=current_user.id,
               details={"evidence_code": evidence.evidence_code, "case_id": case.id})
    return evidence


@app.get("/cases/{case_id}/evidence", response_model=List[schemas.EvidenceOut])
def list_evidence_for_case(case_id: int, db: Session = Depends(get_db),
                            current_user: models.User = Depends(get_current_user)):
    return db.query(models.Evidence).filter(models.Evidence.case_id == case_id).all()


@app.get("/evidence/{evidence_id}", response_model=schemas.EvidenceOut)
def get_evidence(evidence_id: int, db: Session = Depends(get_db),
                  current_user: models.User = Depends(get_current_user)):
    evidence = db.query(models.Evidence).get(evidence_id)
    if not evidence:
        raise HTTPException(status_code=404, detail="Evidence not found")
    return evidence


# ---------------------------------------------------------------------------
# Field Test Events  (+ offline-first sync)
# ---------------------------------------------------------------------------

def _create_field_test_event(payload: schemas.FieldTestEventCreate, db: Session,
                              officer: models.User) -> models.FieldTestEvent:
    evidence = db.query(models.Evidence).get(payload.evidence_id)
    if not evidence:
        raise HTTPException(status_code=404, detail=f"Evidence {payload.evidence_id} not found")

    # Idempotency: if this event_uid was already synced (e.g. retried after a
    # dropped connection), return the existing row instead of duplicating it.
    if payload.event_uid:
        existing = db.query(models.FieldTestEvent).filter(
            models.FieldTestEvent.event_uid == payload.event_uid
        ).first()
        if existing:
            return existing

    event = models.FieldTestEvent(
        event_uid=payload.event_uid,  # None -> model default generates a uuid
        evidence_id=payload.evidence_id,
        officer_id=officer.id,
        test_kit_type=payload.test_kit_type,
        observation=payload.observation,
        preliminary_result=payload.preliminary_result,
        result_status=payload.result_status,
        location_lat=payload.location_lat,
        location_lng=payload.location_lng,
        media_refs=json.dumps(payload.media_refs) if payload.media_refs else None,
        client_created_at=payload.client_created_at,
        synced_at=datetime.utcnow(),
    )
    db.add(event)
    db.commit()
    db.refresh(event)

    # Every field test starts life referable to a lab, not yet referred.
    referral = models.LabReferral(field_test_event_id=event.id, status=models.ReferralStatus.not_referred)
    db.add(referral)
    db.commit()

    log_action(db, "field_test_event", event.id, "create", actor_id=officer.id, details={
        "event_uid": event.event_uid,
        "evidence_id": event.evidence_id,
        "result_status": event.result_status.value,
        "offline_capture": bool(payload.client_created_at),
    })
    return event


@app.post("/field-tests", response_model=schemas.FieldTestEventOut)
def create_field_test(payload: schemas.FieldTestEventCreate, db: Session = Depends(get_db),
                       current_user: models.User = Depends(get_current_user)):
    return _create_field_test_event(payload, db, current_user)


@app.post("/field-tests/sync", response_model=schemas.SyncResult)
def sync_field_tests(batch: schemas.SyncBatch, db: Session = Depends(get_db),
                      current_user: models.User = Depends(get_current_user)):
    """
    Accepts a batch of field-test events queued on-device while offline.
    Idempotent on event_uid, so a retried sync after a partial failure is safe.
    """
    accepted, duplicates = [], []
    for item in batch.events:
        existing = None
        if item.event_uid:
            existing = db.query(models.FieldTestEvent).filter(
                models.FieldTestEvent.event_uid == item.event_uid
            ).first()
        event = _create_field_test_event(item, db, current_user)
        (duplicates if existing else accepted).append(event.event_uid)

    log_action(db, "sync", 0, "sync_batch", actor_id=current_user.id,
               details={"accepted": len(accepted), "duplicates": len(duplicates)})
    return schemas.SyncResult(accepted=accepted, duplicates=duplicates)


@app.get("/field-tests/{event_id}", response_model=schemas.FieldTestEventOut)
def get_field_test(event_id: int, db: Session = Depends(get_db),
                    current_user: models.User = Depends(get_current_user)):
    event = db.query(models.FieldTestEvent).get(event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Field test event not found")
    return event


@app.get("/evidence/{evidence_id}/field-tests", response_model=List[schemas.FieldTestEventOut])
def list_field_tests_for_evidence(evidence_id: int, db: Session = Depends(get_db),
                                   current_user: models.User = Depends(get_current_user)):
    return db.query(models.FieldTestEvent).filter(models.FieldTestEvent.evidence_id == evidence_id).all()


@app.get("/field-tests", response_model=List[schemas.FieldTestEventOut])
def list_field_tests(review_status: Optional[models.ReviewStatus] = None,
                      db: Session = Depends(get_db),
                      current_user: models.User = Depends(get_current_user)):
    q = db.query(models.FieldTestEvent)
    if review_status:
        q = q.filter(models.FieldTestEvent.review_status == review_status)
    return q.order_by(models.FieldTestEvent.created_at.desc()).all()


# ---------------------------------------------------------------------------
# Supervisor review
# ---------------------------------------------------------------------------

@app.post("/field-tests/{event_id}/review", response_model=schemas.FieldTestEventOut)
def review_field_test(event_id: int, payload: schemas.ReviewUpdate, db: Session = Depends(get_db),
                       supervisor: models.User = Depends(require_roles(models.Role.supervisor, models.Role.admin))):
    event = db.query(models.FieldTestEvent).get(event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Field test event not found")

    event.review_status = payload.review_status
    event.supervisor_notes = payload.supervisor_notes
    event.reviewed_by = supervisor.id
    event.reviewed_at = datetime.utcnow()
    db.commit()
    db.refresh(event)

    log_action(db, "field_test_event", event.id, "review", actor_id=supervisor.id, details={
        "review_status": event.review_status.value,
        "notes": event.supervisor_notes,
    })
    return event


# ---------------------------------------------------------------------------
# Lab referral (simulated forensic handoff / status tracking)
# ---------------------------------------------------------------------------

@app.get("/field-tests/{event_id}/referral", response_model=schemas.ReferralOut)
def get_referral(event_id: int, db: Session = Depends(get_db),
                  current_user: models.User = Depends(get_current_user)):
    referral = db.query(models.LabReferral).filter(models.LabReferral.field_test_event_id == event_id).first()
    if not referral:
        raise HTTPException(status_code=404, detail="Referral not found")
    return referral


@app.post("/field-tests/{event_id}/referral", response_model=schemas.ReferralOut)
def update_referral(event_id: int, payload: schemas.ReferralUpdate, db: Session = Depends(get_db),
                     current_user: models.User = Depends(
                         require_roles(models.Role.forensic, models.Role.supervisor, models.Role.admin))):
    referral = db.query(models.LabReferral).filter(models.LabReferral.field_test_event_id == event_id).first()
    if not referral:
        raise HTTPException(status_code=404, detail="Referral not found")

    referral.status = payload.status
    referral.lab_name = payload.lab_name
    referral.notes = payload.notes
    referral.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(referral)

    log_action(db, "lab_referral", referral.id, "update", actor_id=current_user.id, details={
        "status": referral.status.value,
        "lab_name": referral.lab_name,
    })

    # If the lab confirms, promote the field test's result_status automatically.
    if referral.status == models.ReferralStatus.completed:
        event = db.query(models.FieldTestEvent).get(event_id)
        event.result_status = models.ResultStatus.confirmed
        db.commit()
        log_action(db, "field_test_event", event.id, "lab_confirmed", actor_id=current_user.id)

    return referral


# ---------------------------------------------------------------------------
# Timeline & tamper-evident audit trail
# ---------------------------------------------------------------------------

@app.get("/evidence/{evidence_id}/timeline", response_model=List[schemas.TimelineEntry])
def evidence_timeline(evidence_id: int, db: Session = Depends(get_db),
                       current_user: models.User = Depends(get_current_user)):
    evidence = db.query(models.Evidence).get(evidence_id)
    if not evidence:
        raise HTTPException(status_code=404, detail="Evidence not found")

    entries: List[schemas.TimelineEntry] = [
        schemas.TimelineEntry(timestamp=evidence.created_at, label="Evidence registered",
                               detail=evidence.evidence_code)
    ]
    for event in evidence.field_tests:
        entries.append(schemas.TimelineEntry(
            timestamp=event.created_at, label="Field test recorded",
            detail=f"{event.preliminary_result} ({event.result_status.value})",
        ))
        if event.reviewed_at:
            entries.append(schemas.TimelineEntry(
                timestamp=event.reviewed_at, label="Supervisor review",
                detail=event.review_status.value,
            ))
        if event.referral and event.referral.status != models.ReferralStatus.not_referred:
            entries.append(schemas.TimelineEntry(
                timestamp=event.referral.updated_at, label="Lab referral status",
                detail=f"{event.referral.status.value} — {event.referral.lab_name or 'lab TBD'}",
            ))
    entries.sort(key=lambda e: e.timestamp)
    return entries


@app.get("/audit/{entity_type}/{entity_id}", response_model=List[schemas.AuditLogOut])
def audit_for_entity(entity_type: str, entity_id: int, db: Session = Depends(get_db),
                      current_user: models.User = Depends(get_current_user)):
    return db.query(models.AuditLog).filter(
        models.AuditLog.entity_type == entity_type,
        models.AuditLog.entity_id == entity_id,
    ).order_by(models.AuditLog.timestamp.asc()).all()


@app.get("/audit/verify")
def audit_verify(db: Session = Depends(get_db),
                  current_user: models.User = Depends(require_roles(models.Role.supervisor, models.Role.admin))):
    is_valid, broken_id = verify_chain(db)
    return {"valid": is_valid, "first_broken_entry_id": broken_id}


# ---------------------------------------------------------------------------
# Report generation
# ---------------------------------------------------------------------------

@app.get("/field-tests/{event_id}/report", response_class=HTMLResponse)
def generate_report(event_id: int, db: Session = Depends(get_db),
                     current_user: models.User = Depends(get_current_user)):
    event = db.query(models.FieldTestEvent).get(event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Field test event not found")
    evidence = event.evidence
    case = evidence.case
    officer = db.query(models.User).get(event.officer_id)

    disclaimer = ""
    if event.result_status == models.ResultStatus.preliminary:
        disclaimer = (
            "This report documents a PRELIMINARY FIELD OBSERVATION only. "
            "It is not a laboratory-confirmed result and must not be treated as one."
        )

    html = f"""
    <html><head><title>Field Test Report — {event.event_uid}</title>
    <style>
        body {{ font-family: 'IBM Plex Sans', Arial, sans-serif; max-width: 720px; margin: 40px auto; color:#1B2430; }}
        h1 {{ font-size: 20px; border-bottom: 2px solid #1B2430; padding-bottom: 8px; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 16px; }}
        td, th {{ text-align: left; padding: 6px 8px; border-bottom: 1px solid #ccc; font-size: 14px; }}
        .disclaimer {{ margin-top: 20px; padding: 12px; background: #FBEFD9; border-left: 4px solid #A66B1D; font-size: 13px; }}
        .status {{ font-weight: 600; text-transform: capitalize; }}
    </style></head><body>
        <h1>FIELD-TRACE — Field Test Event Report</h1>
        <table>
            <tr><th>Event UID</th><td>{event.event_uid}</td></tr>
            <tr><th>Case</th><td>{case.case_number} — {case.title}</td></tr>
            <tr><th>Evidence ID</th><td>{evidence.evidence_code}</td></tr>
            <tr><th>Officer</th><td>{officer.full_name if officer else event.officer_id}</td></tr>
            <tr><th>Test kit / method</th><td>{event.test_kit_type or 'Not specified'}</td></tr>
            <tr><th>Observation</th><td>{event.observation}</td></tr>
            <tr><th>Preliminary result</th><td>{event.preliminary_result}</td></tr>
            <tr><th>Status</th><td class="status">{event.result_status.value}</td></tr>
            <tr><th>Review status</th><td class="status">{event.review_status.value}</td></tr>
            <tr><th>Supervisor notes</th><td>{event.supervisor_notes or '—'}</td></tr>
            <tr><th>Recorded at</th><td>{event.client_created_at or event.created_at}</td></tr>
            <tr><th>Synced at</th><td>{event.synced_at or '—'}</td></tr>
        </table>
        {f'<div class="disclaimer">{disclaimer}</div>' if disclaimer else ''}
    </body></html>
    """
    log_action(db, "field_test_event", event.id, "report_generated", actor_id=current_user.id)
    return HTMLResponse(content=html)


@app.get("/")
def root():
    return {"service": "FIELD-TRACE API", "status": "running", "docs": "/docs"}
