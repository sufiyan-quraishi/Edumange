/**
 * Thin fetch wrapper for the FIELD-TRACE API. Centralizes the base URL, the
 * bearer token, and JSON/error handling so the rest of the app can call
 * Api.get/post without repeating boilerplate.
 */
const Api = (() => {
  // Change this if the backend runs somewhere other than localhost:8000
  const BASE_URL = "http://localhost:8000";

  function token() {
    return localStorage.getItem("field_trace_token");
  }

  async function request(method, path, body) {
    const headers = { "Content-Type": "application/json" };
    const t = token();
    if (t) headers["Authorization"] = `Bearer ${t}`;

    const res = await fetch(`${BASE_URL}${path}`, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });

    if (res.status === 401) {
      localStorage.removeItem("field_trace_token");
      window.location.reload();
      throw new Error("Session expired");
    }

    if (!res.ok) {
      let detail = res.statusText;
      try {
        const errJson = await res.json();
        detail = errJson.detail || detail;
      } catch (_) {}
      throw new Error(detail);
    }

    const contentType = res.headers.get("content-type") || "";
    if (contentType.includes("application/json")) return res.json();
    return res.text();
  }

  return {
    get: (path) => request("GET", path),
    post: (path, body) => request("POST", path, body),

    async login(username, password) {
      const form = new URLSearchParams();
      form.append("username", username);
      form.append("password", password);
      const res = await fetch(`${BASE_URL}/auth/login`, { method: "POST", body: form });
      if (!res.ok) {
        let detail = "Login failed";
        try { detail = (await res.json()).detail || detail; } catch (_) {}
        throw new Error(detail);
      }
      return res.json();
    },

    reportUrl(eventId) {
      return `${BASE_URL}/field-tests/${eventId}/report`;
    },

    async isReachable() {
      if (!navigator.onLine) return false;
      try {
        const res = await fetch(`${BASE_URL}/`, { method: "GET", cache: "no-store" });
        return res.ok;
      } catch (_) {
        return false;
      }
    },
  };
})();
