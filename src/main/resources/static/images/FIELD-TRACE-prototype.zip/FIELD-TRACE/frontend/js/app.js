/**
 * FIELD-TRACE frontend application (vanilla JS, no build step).
 *
 * Flow implemented: officer login -> case -> evidence -> field-test event
 * (captured offline-first) -> sync -> report -> supervisor review ->
 * evidence timeline / tamper-evident audit -> simulated lab status.
 */

const state = {
  user: null,              // { username, full_name, role }
  view: "cases",
  params: {},
  online: navigator.onLine,
};

const el = (id) => document.getElementById(id);
const content = () => el("content");

function escapeHtml(s) {
  if (s === null || s === undefined) return "";
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}
function fmtDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------

async function doLogin() {
  const username = el("login-username").value.trim();
  const password = el("login-password").value;
  el("login-error").innerHTML = "";
  if (!username || !password) {
    el("login-error").innerHTML = `<div class="error-box">Enter a username and password.</div>`;
    return;
  }
  try {
    const res = await Api.login(username, password);
    localStorage.setItem("field_trace_token", res.access_token);
    localStorage.setItem("field_trace_user", JSON.stringify({
      username, full_name: res.full_name, role: res.role,
    }));
    boot();
  } catch (e) {
    el("login-error").innerHTML = `<div class="error-box">${escapeHtml(e.message)}</div>`;
  }
}

function doLogout() {
  localStorage.removeItem("field_trace_token");
  localStorage.removeItem("field_trace_user");
  state.user = null;
  el("app").style.display = "none";
  el("login-screen").style.display = "flex";
}

function boot() {
  const raw = localStorage.getItem("field_trace_user");
  if (!raw || !localStorage.getItem("field_trace_token")) return;
  state.user = JSON.parse(raw);

  el("login-screen").style.display = "none";
  el("app").style.display = "flex";
  el("who-name").textContent = state.user.full_name;
  el("who-role").textContent = state.user.role;

  el("nav-review").style.display = ["supervisor", "admin"].includes(state.user.role) ? "flex" : "none";
  el("nav-lab").style.display = ["forensic", "supervisor", "admin"].includes(state.user.role) ? "flex" : "none";

  navigate("cases");
  startConnectivityWatcher();
}

// ---------------------------------------------------------------------------
// Navigation
// ---------------------------------------------------------------------------

function navigate(view, params = {}) {
  state.view = view;
  state.params = params;
  document.querySelectorAll(".nav-item").forEach((n) => {
    n.classList.toggle("active", n.dataset.view === view);
  });
  render();
}

window.navigate = navigate;

document.addEventListener("DOMContentLoaded", () => {
  el("login-btn").addEventListener("click", doLogin);
  el("login-password").addEventListener("keydown", (e) => { if (e.key === "Enter") doLogin(); });
  el("logout-btn").addEventListener("click", doLogout);
  document.querySelectorAll(".nav-item[data-view]").forEach((n) => {
    n.addEventListener("click", () => navigate(n.dataset.view));
  });
  boot();
});

// ---------------------------------------------------------------------------
// Render dispatcher
// ---------------------------------------------------------------------------

async function render() {
  const titles = {
    cases: "Cases", case_detail: "Case detail", evidence_detail: "Evidence & field tests",
    field_test_detail: "Field test event", review: "Review queue", lab: "Lab referrals",
    audit: "Audit trail integrity",
  };
  el("page-title").textContent = titles[state.view] || "FIELD-TRACE";
  content().innerHTML = `<div class="empty">Loading…</div>`;

  try {
    if (state.view === "cases") return renderCases();
    if (state.view === "case_detail") return renderCaseDetail(state.params.caseId);
    if (state.view === "evidence_detail") return renderEvidenceDetail(state.params.evidenceId);
    if (state.view === "field_test_detail") return renderFieldTestDetail(state.params.eventId, state.params.evidenceId);
    if (state.view === "review") return renderReviewQueue();
    if (state.view === "lab") return renderLabQueue();
    if (state.view === "audit") return renderAuditView();
  } catch (e) {
    content().innerHTML = `<div class="error-box">${escapeHtml(e.message)}</div>`;
  }
}

// ---------------------------------------------------------------------------
// Cases
// ---------------------------------------------------------------------------

async function renderCases() {
  let cases;
  try {
    cases = await Api.get("/cases");
    await FieldTraceDB.setCache("cases", cases);
  } catch (e) {
    cases = (await FieldTraceDB.getCache("cases")) || [];
    content().innerHTML = `<div class="notice-box">Showing last-synced cases — could not reach the server.</div>`;
  }

  const rows = cases.length
    ? cases.map((c) => `
      <div class="list-row" onclick="navigate('case_detail', {caseId: ${c.id}})">
        <div>
          <div class="list-title">${escapeHtml(c.case_number)} — ${escapeHtml(c.title)}</div>
          <div class="list-sub">${escapeHtml(c.description || "")}</div>
        </div>
        <span class="tag ${c.status === "open" ? "pending" : "confirmed"}">${escapeHtml(c.status)}</span>
      </div>
    `).join("")
    : `<div class="empty">No cases yet. Register one below.</div>`;

  content().innerHTML += `
    <div class="panel">
      <h2>Active cases</h2>
      <div class="meta">Case → Evidence → Field Test Event is the record hierarchy for every entry below.</div>
      ${rows}
    </div>
    <div class="panel">
      <h2>Register new case</h2>
      <form id="case-form">
        <label>Case number</label>
        <input type="text" id="cf-number" placeholder="e.g. MH-CR-2026-0143" required />
        <label>Title</label>
        <input type="text" id="cf-title" placeholder="Short case title" required />
        <label>Description <span class="hint">optional</span></label>
        <textarea id="cf-desc"></textarea>
        <div class="actions"><button type="submit" class="btn">Create case</button></div>
      </form>
    </div>
  `;

  el("case-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      await Api.post("/cases", {
        case_number: el("cf-number").value.trim(),
        title: el("cf-title").value.trim(),
        description: el("cf-desc").value.trim() || null,
      });
      navigate("cases");
    } catch (err) {
      content().insertAdjacentHTML("afterbegin", `<div class="error-box">${escapeHtml(err.message)}</div>`);
    }
  });
}

// ---------------------------------------------------------------------------
// Case detail -> Evidence list
// ---------------------------------------------------------------------------

async function renderCaseDetail(caseId) {
  const cacheKey = `case_${caseId}`;
  let caseObj, evidence;
  try {
    caseObj = await Api.get(`/cases/${caseId}`);
    evidence = await Api.get(`/cases/${caseId}/evidence`);
    await FieldTraceDB.setCache(cacheKey, { caseObj, evidence });
  } catch (e) {
    const cached = await FieldTraceDB.getCache(cacheKey);
    if (!cached) { content().innerHTML = `<div class="error-box">${escapeHtml(e.message)}</div>`; return; }
    ({ caseObj, evidence } = cached);
    content().innerHTML = `<div class="notice-box">Showing last-synced case data — offline.</div>`;
  }

  const rows = evidence.length
    ? evidence.map((ev) => `
      <div class="list-row" onclick="navigate('evidence_detail', {evidenceId: ${ev.id}})">
        <div>
          <div class="list-title mono">${escapeHtml(ev.evidence_code)}</div>
          <div class="list-sub">${escapeHtml(ev.description)}</div>
        </div>
        <div class="list-sub">${fmtDate(ev.seized_at)}</div>
      </div>
    `).join("")
    : `<div class="empty">No evidence registered for this case yet.</div>`;

  content().innerHTML += `
    <div class="panel">
      <button class="btn secondary" onclick="navigate('cases')">&larr; All cases</button>
      <h2 style="margin-top:14px">${escapeHtml(caseObj.case_number)} — ${escapeHtml(caseObj.title)}</h2>
      <div class="meta">${escapeHtml(caseObj.description || "")} · Status: ${escapeHtml(caseObj.status)}</div>
    </div>
    <div class="panel">
      <h2>Evidence items</h2>
      ${rows}
    </div>
    <div class="panel">
      <h2>Register evidence</h2>
      <form id="evidence-form">
        <label>Description</label>
        <textarea id="ef-desc" placeholder="Physical description of the seized item" required></textarea>
        <label>Seizure location <span class="hint">optional</span></label>
        <input type="text" id="ef-location" placeholder="e.g. NH-48, KM marker 22" />
        <div class="actions"><button type="submit" class="btn">Register evidence</button></div>
      </form>
    </div>
  `;

  el("evidence-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      await Api.post("/evidence", {
        case_id: caseId,
        description: el("ef-desc").value.trim(),
        seized_location: el("ef-location").value.trim() || null,
      });
      navigate("case_detail", { caseId });
    } catch (err) {
      content().insertAdjacentHTML("afterbegin", `<div class="error-box">${escapeHtml(err.message)}</div>`);
    }
  });
}

// ---------------------------------------------------------------------------
// Evidence detail -> Field test events (the offline-first capture point)
// ---------------------------------------------------------------------------

function uuidv4() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0, v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

async function renderEvidenceDetail(evidenceId) {
  const cacheKey = `evidence_${evidenceId}`;
  let evidenceObj, tests;
  try {
    evidenceObj = await Api.get(`/evidence/${evidenceId}`);
    tests = await Api.get(`/evidence/${evidenceId}/field-tests`);
    await FieldTraceDB.setCache(cacheKey, { evidenceObj, tests });
  } catch (e) {
    const cached = await FieldTraceDB.getCache(cacheKey);
    if (!cached) { content().innerHTML = `<div class="error-box">${escapeHtml(e.message)}</div>`; return; }
    ({ evidenceObj, tests } = cached);
    content().innerHTML = `<div class="notice-box">Showing last-synced evidence data — offline. New field tests will still be captured and queued.</div>`;
  }

  const queued = (await FieldTraceDB.getQueuedEvents()).filter((q) => q.evidence_id === evidenceId);

  const rows = tests.length || queued.length
    ? tests.map((t) => `
      <div class="list-row" onclick="navigate('field_test_detail', {eventId: ${t.id}, evidenceId: ${evidenceId}})">
        <div>
          <div class="list-title">${escapeHtml(t.preliminary_result)}</div>
          <div class="list-sub mono">${escapeHtml(t.event_uid)} · ${fmtDate(t.created_at)}</div>
        </div>
        <div style="display:flex; gap:6px;">
          <span class="tag ${t.result_status}">${escapeHtml(t.result_status)}</span>
          <span class="tag ${t.review_status}">${escapeHtml(t.review_status)}</span>
        </div>
      </div>
    `).join("") + queued.map((q) => `
      <div class="list-row">
        <div>
          <div class="list-title">${escapeHtml(q.preliminary_result)}</div>
          <div class="list-sub mono">${escapeHtml(q.event_uid)} · captured ${fmtDate(q.client_created_at)}</div>
        </div>
        <span class="tag queued">queued — not synced</span>
      </div>
    `).join("")
    : `<div class="empty">No field tests recorded for this evidence yet.</div>`;

  content().innerHTML += `
    <div class="panel">
      <button class="btn secondary" onclick="navigate('case_detail', {caseId: ${evidenceObj.case_id}})">&larr; Back to case</button>
      <h2 style="margin-top:14px" class="mono">${escapeHtml(evidenceObj.evidence_code)}</h2>
      <div class="meta">${escapeHtml(evidenceObj.description)} — seized ${fmtDate(evidenceObj.seized_at)} at ${escapeHtml(evidenceObj.seized_location || "unspecified location")}</div>
      <button class="btn secondary" onclick="navigate('evidence_timeline_inline')" style="display:none"></button>
      <a href="#" onclick="event.preventDefault(); showTimeline(${evidenceId})">View evidence timeline &amp; audit trail →</a>
    </div>

    <div class="panel">
      <h2>Record field test</h2>
      <div class="meta">Saved to this device immediately. Synced automatically when a connection is available — works fully offline.</div>
      <form id="ft-form">
        <label>Test kit / method</label>
        <input type="text" id="ft-kit" placeholder="e.g. NCB presumptive kit — opiates" />
        <label>Field observation</label>
        <textarea id="ft-observation" placeholder="Describe exactly what was observed during the test" required></textarea>
        <label>Preliminary result</label>
        <input type="text" id="ft-result" placeholder="e.g. presumptive positive — opiates" required />
        <label>Result status</label>
        <select id="ft-status">
          <option value="preliminary" selected>Preliminary (field observation only)</option>
          <option value="inconclusive">Inconclusive</option>
        </select>
        <div class="field-row">
          <div>
            <label>Latitude <span class="hint">optional</span></label>
            <input type="number" step="any" id="ft-lat" />
          </div>
          <div>
            <label>Longitude <span class="hint">optional</span></label>
            <input type="number" step="any" id="ft-lng" />
          </div>
        </div>
        <div class="actions"><button type="submit" class="btn">Save field test event</button></div>
      </form>
    </div>

    <div class="panel">
      <h2>Field test events</h2>
      ${rows}
    </div>
  `;

  el("ft-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const event = {
      event_uid: uuidv4(),
      evidence_id: evidenceId,
      test_kit_type: el("ft-kit").value.trim() || null,
      observation: el("ft-observation").value.trim(),
      preliminary_result: el("ft-result").value.trim(),
      result_status: el("ft-status").value,
      location_lat: el("ft-lat").value ? parseFloat(el("ft-lat").value) : null,
      location_lng: el("ft-lng").value ? parseFloat(el("ft-lng").value) : null,
      client_created_at: new Date().toISOString(),
    };
    // Offline-first: always queue locally first, regardless of connectivity.
    await FieldTraceDB.queueEvent(event);
    updateSyncPill();

    const reachable = await Api.isReachable();
    if (reachable) {
      await trySync();
    }
    navigate("evidence_detail", { evidenceId });
  });
}

window.showTimeline = async (evidenceId) => {
  navigate("evidence_detail", { evidenceId }); // ensure context stays consistent
  const timeline = await Api.get(`/evidence/${evidenceId}/timeline`).catch(() => []);
  const entries = timeline.map((t) => `
    <div class="timeline-entry">
      <div class="ts">${fmtDate(t.timestamp)}</div>
      <div class="label">${escapeHtml(t.label)}</div>
      ${t.detail ? `<div class="detail">${escapeHtml(t.detail)}</div>` : ""}
    </div>
  `).join("") || `<div class="empty">No timeline entries yet.</div>`;

  content().insertAdjacentHTML("beforeend", `
    <div class="panel" id="timeline-panel">
      <h2>Evidence timeline</h2>
      <div class="timeline">${entries}</div>
    </div>
  `);
  el("timeline-panel").scrollIntoView({ behavior: "smooth" });
};

// ---------------------------------------------------------------------------
// Field test detail: report, review (supervisor), referral (forensic)
// ---------------------------------------------------------------------------

async function renderFieldTestDetail(eventId, evidenceId) {
  const t = await Api.get(`/field-tests/${eventId}`);
  let referral = null;
  try { referral = await Api.get(`/field-tests/${eventId}/referral`); } catch (_) {}

  const canReview = ["supervisor", "admin"].includes(state.user.role);
  const canRefer = ["forensic", "supervisor", "admin"].includes(state.user.role);

  content().innerHTML = `
    <div class="panel">
      <button class="btn secondary" onclick="navigate('evidence_detail', {evidenceId: ${evidenceId}})">&larr; Back to evidence</button>
      <h2 style="margin-top:14px">Field test event</h2>
      <div class="meta mono">${escapeHtml(t.event_uid)}</div>
      <table style="width:100%; margin-top:10px; font-size:14px;">
        <tr><td style="color:var(--ink-soft); padding:4px 0; width:170px;">Test kit / method</td><td>${escapeHtml(t.test_kit_type || "—")}</td></tr>
        <tr><td style="color:var(--ink-soft); padding:4px 0;">Observation</td><td>${escapeHtml(t.observation)}</td></tr>
        <tr><td style="color:var(--ink-soft); padding:4px 0;">Preliminary result</td><td>${escapeHtml(t.preliminary_result)}</td></tr>
        <tr><td style="color:var(--ink-soft); padding:4px 0;">Status</td><td><span class="tag ${t.result_status}">${escapeHtml(t.result_status)}</span></td></tr>
        <tr><td style="color:var(--ink-soft); padding:4px 0;">Review status</td><td><span class="tag ${t.review_status}">${escapeHtml(t.review_status)}</span></td></tr>
        <tr><td style="color:var(--ink-soft); padding:4px 0;">Supervisor notes</td><td>${escapeHtml(t.supervisor_notes || "—")}</td></tr>
        <tr><td style="color:var(--ink-soft); padding:4px 0;">Captured</td><td>${fmtDate(t.client_created_at || t.created_at)}</td></tr>
        <tr><td style="color:var(--ink-soft); padding:4px 0;">Synced</td><td>${fmtDate(t.synced_at)}</td></tr>
      </table>
      ${t.result_status === "preliminary" ? `<div class="notice-box" style="margin-top:14px">Preliminary field observation only — not a laboratory-confirmed result.</div>` : ""}
      <div class="actions">
        <a class="btn" target="_blank" href="${Api.reportUrl(t.id)}">Generate report</a>
      </div>
    </div>

    ${canReview ? `
      <div class="panel">
        <h2>Supervisor review</h2>
        <form id="review-form">
          <label>Review status</label>
          <select id="rv-status">
            <option value="pending" ${t.review_status === "pending" ? "selected" : ""}>Pending</option>
            <option value="reviewed" ${t.review_status === "reviewed" ? "selected" : ""}>Reviewed</option>
            <option value="flagged" ${t.review_status === "flagged" ? "selected" : ""}>Flagged for discrepancy</option>
          </select>
          <label>Notes <span class="hint">optional</span></label>
          <textarea id="rv-notes">${escapeHtml(t.supervisor_notes || "")}</textarea>
          <div class="actions"><button type="submit" class="btn">Submit review</button></div>
        </form>
      </div>
    ` : ""}

    ${canRefer && referral ? `
      <div class="panel">
        <h2>Lab referral status</h2>
        <div class="meta">Simulated forensic handoff for prototype demo purposes.</div>
        <form id="referral-form">
          <label>Status</label>
          <select id="rf-status">
            <option value="not_referred" ${referral.status === "not_referred" ? "selected" : ""}>Not referred</option>
            <option value="referred" ${referral.status === "referred" ? "selected" : ""}>Referred to lab</option>
            <option value="in_analysis" ${referral.status === "in_analysis" ? "selected" : ""}>In analysis</option>
            <option value="completed" ${referral.status === "completed" ? "selected" : ""}>Completed — confirms result</option>
          </select>
          <label>Lab name <span class="hint">optional</span></label>
          <input type="text" id="rf-lab" value="${escapeHtml(referral.lab_name || "")}" />
          <label>Notes <span class="hint">optional</span></label>
          <textarea id="rf-notes">${escapeHtml(referral.notes || "")}</textarea>
          <div class="actions"><button type="submit" class="btn">Update referral</button></div>
        </form>
      </div>
    ` : ""}
  `;

  if (canReview) {
    el("review-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      await Api.post(`/field-tests/${eventId}/review`, {
        review_status: el("rv-status").value,
        supervisor_notes: el("rv-notes").value.trim() || null,
      });
      navigate("field_test_detail", { eventId, evidenceId });
    });
  }
  if (canRefer && referral) {
    el("referral-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      await Api.post(`/field-tests/${eventId}/referral`, {
        status: el("rf-status").value,
        lab_name: el("rf-lab").value.trim() || null,
        notes: el("rf-notes").value.trim() || null,
      });
      navigate("field_test_detail", { eventId, evidenceId });
    });
  }
}

// ---------------------------------------------------------------------------
// Review queue (supervisor / admin)
// ---------------------------------------------------------------------------

async function renderReviewQueue() {
  const pending = await Api.get("/field-tests?review_status=pending");
  const rows = pending.length
    ? pending.map((t) => `
      <div class="list-row" onclick="navigate('field_test_detail', {eventId: ${t.id}, evidenceId: ${t.evidence_id}})">
        <div>
          <div class="list-title">${escapeHtml(t.preliminary_result)}</div>
          <div class="list-sub mono">${escapeHtml(t.event_uid)} · ${fmtDate(t.created_at)}</div>
        </div>
        <span class="tag ${t.result_status}">${escapeHtml(t.result_status)}</span>
      </div>
    `).join("")
    : `<div class="empty">No field tests awaiting review. Queue is clear.</div>`;

  content().innerHTML = `<div class="panel"><h2>Pending supervisor review</h2>${rows}</div>`;
}

// ---------------------------------------------------------------------------
// Lab referrals (forensic / supervisor / admin)
// ---------------------------------------------------------------------------

async function renderLabQueue() {
  const all = await Api.get("/field-tests");
  const rows = all.length
    ? all.map((t) => `
      <div class="list-row" onclick="navigate('field_test_detail', {eventId: ${t.id}, evidenceId: ${t.evidence_id}})">
        <div>
          <div class="list-title">${escapeHtml(t.preliminary_result)}</div>
          <div class="list-sub mono">${escapeHtml(t.event_uid)}</div>
        </div>
        <span class="tag ${t.result_status}">${escapeHtml(t.result_status)}</span>
      </div>
    `).join("")
    : `<div class="empty">No field test events yet.</div>`;

  content().innerHTML = `
    <div class="panel">
      <h2>All field test events</h2>
      <div class="meta">Open an event to update its lab referral status. Marking a referral "Completed" promotes the event to laboratory-confirmed.</div>
      ${rows}
    </div>
  `;
}

// ---------------------------------------------------------------------------
// Audit integrity view
// ---------------------------------------------------------------------------

async function renderAuditView() {
  content().innerHTML = `<div class="panel"><h2>Tamper-evident audit chain</h2><div class="empty">Checking…</div></div>`;
  try {
    const result = await Api.get("/audit/verify");
    content().innerHTML = `
      <div class="panel">
        <h2>Tamper-evident audit chain</h2>
        <div class="meta">Every action (create, review, sync, referral update) is hashed together with the previous entry's hash. Re-walking the chain detects any retroactive edit.</div>
        <div class="tag ${result.valid ? "confirmed" : "flagged"}" style="font-size:14px; padding:6px 12px;">
          ${result.valid ? "Chain intact — no tampering detected" : `Chain broken at entry #${result.first_broken_entry_id}`}
        </div>
      </div>
    `;
  } catch (e) {
    content().innerHTML = `<div class="error-box">${escapeHtml(e.message)} — audit verification requires a supervisor or admin role.</div>`;
  }
}

// ---------------------------------------------------------------------------
// Connectivity + offline sync loop
// ---------------------------------------------------------------------------

async function updateSyncPill() {
  const count = await FieldTraceDB.countQueued();
  const pill = el("pending-sync");
  if (count > 0) {
    pill.style.display = "inline-flex";
    el("pending-count-text").textContent = `${count} queued for sync`;
  } else {
    pill.style.display = "none";
  }
}

async function trySync() {
  const queued = await FieldTraceDB.getQueuedEvents();
  if (queued.length === 0) return;
  try {
    const result = await Api.post("/field-tests/sync", { events: queued });
    for (const uid of [...result.accepted, ...result.duplicates]) {
      await FieldTraceDB.removeQueuedEvent(uid);
    }
  } catch (_) {
    // stays queued, will retry on next connectivity check
  }
  updateSyncPill();
}

function startConnectivityWatcher() {
  const pill = el("sync-status");
  const check = async () => {
    const reachable = await Api.isReachable();
    state.online = reachable;
    pill.className = `sync-pill ${reachable ? "online" : "offline"}`;
    pill.innerHTML = `<span class="dot"></span>${reachable ? "Online" : "Offline — capturing locally"}`;
    if (reachable) await trySync();
    await updateSyncPill();
  };
  check();
  setInterval(check, 15000);
  window.addEventListener("online", check);
  window.addEventListener("offline", check);
}
