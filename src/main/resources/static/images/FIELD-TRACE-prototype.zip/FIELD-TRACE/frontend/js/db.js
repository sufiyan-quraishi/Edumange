/**
 * FieldTraceDB — thin IndexedDB wrapper providing:
 *   - "outbox": field-test events captured while offline, queued for sync
 *   - "cache":  last-known-good copies of cases/evidence/field-tests, so the
 *               officer can still browse case context with no signal
 *
 * This is the offline-first backbone: the UI always writes to IndexedDB
 * first, then opportunistically pushes to the server when a connection
 * exists. Nothing about capturing a field-test event requires network.
 */
const FieldTraceDB = (() => {
  const DB_NAME = "field_trace_offline";
  const DB_VERSION = 1;
  let dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains("outbox")) {
          db.createObjectStore("outbox", { keyPath: "event_uid" });
        }
        if (!db.objectStoreNames.contains("cache")) {
          db.createObjectStore("cache", { keyPath: "key" });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }

  async function tx(storeName, mode) {
    const db = await open();
    return db.transaction(storeName, mode).objectStore(storeName);
  }

  return {
    async queueEvent(event) {
      const store = await tx("outbox", "readwrite");
      return new Promise((resolve, reject) => {
        const req = store.put(event);
        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
      });
    },

    async getQueuedEvents() {
      const store = await tx("outbox", "readonly");
      return new Promise((resolve, reject) => {
        const req = store.getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => reject(req.error);
      });
    },

    async removeQueuedEvent(event_uid) {
      const store = await tx("outbox", "readwrite");
      return new Promise((resolve, reject) => {
        const req = store.delete(event_uid);
        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
      });
    },

    async countQueued() {
      const items = await this.getQueuedEvents();
      return items.length;
    },

    async setCache(key, value) {
      const store = await tx("cache", "readwrite");
      return new Promise((resolve, reject) => {
        const req = store.put({ key, value, cachedAt: Date.now() });
        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
      });
    },

    async getCache(key) {
      const store = await tx("cache", "readonly");
      return new Promise((resolve, reject) => {
        const req = store.get(key);
        req.onsuccess = () => resolve(req.result ? req.result.value : null);
        req.onerror = () => reject(req.error);
      });
    },
  };
})();
