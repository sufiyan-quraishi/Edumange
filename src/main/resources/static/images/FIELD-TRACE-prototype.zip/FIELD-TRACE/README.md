# FIELD-TRACE — Field Testing & Evidence Traceability Companion

Working prototype for **SIH26231** (Ministry of Home Affairs). A secure,
offline-first digital bridge between field drug testing and the forensic
evidence workflow.

Implements the flow from the analysis document's prototype plan:

```
Officer login → Case → Evidence → Field Test Event → Offline capture → Sync
→ Report → Supervisor review → Evidence timeline & audit trail → Lab status
```

## Stack

- **Backend:** Python + FastAPI, SQLAlchemy ORM, SQLite (swap for PostgreSQL
  in production by changing one line in `backend/database.py`)
- **Frontend:** plain HTML / CSS / JavaScript (no build step), IndexedDB for
  offline-first field-test capture
- **Auth:** JWT bearer tokens, role-based access (officer / supervisor /
  forensic / admin)
- **Audit:** hash-chained tamper-evident log (`backend/audit.py`) — every
  create/review/sync/referral action is chained to the previous entry's
  SHA-256 hash, so a re-walk of the chain detects retroactive edits

## Project layout

```
FIELD-TRACE/
├── backend/
│   ├── main.py          FastAPI app & all routes
│   ├── models.py        SQLAlchemy models (Case, Evidence, FieldTestEvent,
│   │                    LabReferral, AuditLog, User)
│   ├── schemas.py       Pydantic request/response schemas
│   ├── auth.py          Password hashing, JWT, role-based dependencies
│   ├── audit.py         Hash-chained audit log helper
│   ├── database.py      SQLAlchemy engine/session (SQLite by default)
│   ├── seed.py          Creates demo users + a demo case/evidence
│   └── requirements.txt
└── frontend/
    ├── index.html
    ├── css/style.css
    └── js/
        ├── api.js       Fetch wrapper (auth header, base URL, error handling)
        ├── db.js         IndexedDB wrapper — offline outbox + read cache
        └── app.js        App shell, routing, and all views
```

## Running it

**1. Backend**

```bash
cd backend
python3 -m venv venv && source venv/bin/activate     # optional but recommended
pip install -r requirements.txt
python seed.py            # creates demo accounts + a demo case/evidence
uvicorn main:app --reload
```

The API comes up at `http://localhost:8000`. Interactive docs (Swagger UI)
are auto-generated at `http://localhost:8000/docs` — useful for exercising
endpoints directly (e.g. simulating a lab referral update) without the UI.

**2. Frontend**

The frontend is static — no build step. Serve the folder with any static
file server (opening `index.html` directly via `file://` will hit CORS
issues in some browsers, so a local server is recommended):

```bash
cd frontend
python3 -m http.server 5500
```

Then open `http://localhost:5500` in a browser. If your backend runs on a
different host/port, update `BASE_URL` in `frontend/js/api.js`.

**3. Demo logins** (created by `seed.py`)

| Role       | Username     | Password   |
|------------|--------------|------------|
| Officer    | officer1     | officer123 |
| Supervisor | supervisor1  | super123   |
| Forensic   | lab1         | lab123     |
| Admin      | admin        | admin123   |

## Demo walkthrough (matches the prototype plan)

1. Log in as **officer1**. A demo case (`MH-CR-2026-0142`) and one evidence
   item are pre-seeded — open the case, then the evidence item.
2. Fill in the **Record field test** form and save. It's written to
   IndexedDB immediately and synced to the server if reachable.
3. To see offline capture: turn off networking (or stop the backend), record
   another field test — it queues locally with a "queued — not synced" tag
   and a purple "Offline — capturing locally" pill appears top-right.
4. Restart the backend / reconnect — the app auto-syncs on the next
   connectivity check (every 15s) or immediately on the browser's `online`
   event, and the queued tag disappears.
5. Open a field test event → **Generate report** for a structured HTML
   report, clearly labeled "preliminary field observation" until a lab
   confirms it.
6. Log in as **supervisor1** → **Review queue** → open an event → submit a
   review (reviewed / flagged + notes).
7. Log in as **lab1** (forensic role) → **Lab referrals** → open an event →
   set status to "Completed" — this automatically promotes the field test's
   result to laboratory-confirmed.
8. From any evidence page, click **View evidence timeline & audit trail** to
   see the full chronological record. The **Audit integrity** nav item
   (supervisor/admin) re-walks the hash chain and reports whether any entry
   has been tampered with.

## Notes on scope (see the source analysis document, §13 "Brutal Reality Check")

- This is a **software workflow prototype**, not a chemical/analytical
  testing device — it digitizes and structures the *documentation* around an
  authorised physical field test, it does not perform drug identification.
- AI is intentionally **not** used for definitive substance identification
  anywhere in this codebase — only structural/workflow assistance is in
  scope per the source analysis (§7).
- No real ICJS / e-Forensics integration is implemented; the "API-ready
  architecture" opportunity is represented by the FastAPI backend's clean
  REST surface, ready for an authorised interoperability layer later.
- `SECRET_KEY` in `backend/auth.py` is hardcoded for local demo convenience
  only — replace with an environment-loaded secret before any real
  deployment.
